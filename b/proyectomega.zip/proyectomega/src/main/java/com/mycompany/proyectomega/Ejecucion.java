/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejecucion {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        Admin admd = new Admin();
        Usuario user = new Usuario(admd);
        boolean a = false;
        while (!a){
            System.out.println("Bienvenido");
            System.out.println("digite una opcion:");
            System.out.println("1. administrador");
            System.out.println("2. usuario");
            System.out.print("3.salir ");
            scanner.nextLine();
            int opcion1 = scanner.nextInt();
            scanner.nextLine();
            switch (opcion1){
                case 1 -> {
                    System.out.print("digite la contraseña: ");
                    String pass = scanner.nextLine();
                    if (admd.check(pass)) {
                        menu1.meme1(admd, scanner);
                    } else {
                        System.out.println("Contraseña incorrecta.");
                        break;
                    }
                    break;
                }
                case 2 -> {
                    menu2.meme2 (user, scanner);
                    break;
                }
                case 3 -> {
                    a= true;
                    System.out.println("saliendo");
                    break; 

                }
                default -> {
                    System.out.println("error");
                }
            }
        }
        scanner.close();
    }
}
    