/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;

import java.io.Serializable;
import java.util.ArrayList;
/**
 *
 * @author Usuario
 */
class Usuario implements Serializable{
    private Admin admd;
    private java.util.ArrayList <Game> compra;
    
    public Usuario (Admin ad){
        this.admd = admd;
        this.compra = new ArrayList<>();
    }
    public Game Buscar (String room){
        for (Game g : admd.getinvent()){
            if (g.getroom().equals(room)){
                return g;
            }
        }
    return null;
    }
    public void mostrar(){
        if (admd.getinvent().isEmpty()){
            System.out.println("no hay salas");
        }
        for(Game g: admd.getinvent()){
            System.out.print(g);
        }
    }
    public boolean pedir (String room){
        Game game = Buscar(room);
        if (game != null){
            compra.add(game);
            return true;
        }
        return false;
    }
     public java.util.ArrayList<Game> getcompra(){
        return new java.util.ArrayList<>(compra);
    }
}