/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectomega;
import java.io.Serializable;
import java.util.Objects;
/**
 *
 * @author Usuario
 */
public class Game implements Serializable{
    private String room;
    private String consola;
    private String opc1;
    private String opc2;
    private String opc3;
    private String opc4;
    private String opc5;
    private String opc6;
    private String opc7;
    private String opc8;
    private double precio;
    private String videog;
    private boolean disponibilidad;
    public Game(String room, String consola, String videog, double precio, boolean disponibilidad) {
        this.room = room;
        this.consola = consola;
        this.opc1 = "10:00 am a 11:00 am";
        this.opc2 = "11:00 am a 12:00 pm";
        this.opc3 = "12:00 pm a 1:00 pm";
        this.opc4 = "1:00 pm a 2:00 pm";
        this.opc5 = "2:00 pm a 3:00 pm";
        this.opc6 = "3:00 pm a 4:00 pm";
        this.opc7 = "4:00 pm a 5:00 pm";
        this.opc8 = "5:00 pm a 6:00 pm";
        this.videog = videog;
        this.precio = precio;
        this.disponibilidad = disponibilidad;
        
    }
    public String getroom(){
        return room;
    }
    public void setroom(String room){
        this.room = room;
    }
    public String getconsola(){
        return consola;
    }
    public void setconsola(String consola){
        this.consola = consola;
    }
    public String getopc1(){
        return opc1;
    }
    public void setopc1(String opc1){
        this.opc1 = opc1;
    }
    public String getopc2(){
        return opc2;
    }
    public void setopc2(String opc2){
        this.opc2 = opc2;
    }
    public String getopc3(){
        return opc3;
    }
    public void setopc3(String opc3){
        this.opc3 = opc3;
    }
    public String getopc4(){
        return opc4;
    }
    public void setopc4(String opc4){
        this.opc4 = opc4;
    }
    public String getopc5(){
        return opc5;
    }
    public void setopc5(String opc5){
        this.opc5 = opc5;
    }
    public String getopc6(){
        return opc6;
    }
    public void setopc6(String opc6){
        this.opc6 = opc6;
    }
    public String getopc7(){
        return opc7;
    }
    public void setopc7(String opc7){
        this.opc7 = opc7;
    }
    public String getopc8(){
        return opc8;
    }
    public void setopc8(String opc8){
        this.opc8 = opc8;
    }
    public double getprecio(){
        return precio;
    }
    public void setprecio(double precio){
        this.precio = precio;
    }
    public String getvideog(){
        return videog;
    }
    public void setvideog(String videog){
        this.videog = videog;
    }
    public boolean getdisponibilidad(){
        return disponibilidad;
    }
    public void setdisponibilidad(boolean disponibilidad){
        this.disponibilidad = disponibilidad;
    }
    @Override
    public String toString(){
        return "numero de sala :"+ room+" \n Nombre de la consola :" + consola +"\n nombre del juego a usar :"+ videog + "\n Disponibilidad de consola :"+ disponibilidad  + "\n Valor a pagar :" + precio;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Game juego = (Game) obj;
        return Objects.equals(room, juego.room);
    }

    @Override
    public int hashCode() {
        return Objects.hash(room);
    }
}