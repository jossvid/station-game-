/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;

/**
 *
 * @author Usuario
 */
public class Username extends Game implements Save {
    public String nombre;
    public String opdef;
    public Username(String room, String consola, String videog, double precio, boolean disponibilidad) {
        super(room, consola, videog, precio, disponibilidad);
    }
    public String getNombre() {
        return nombre;
    }    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getOpdef() {
        return opdef;
    }    
    public void setOpdef(String opdef) {
        this.opdef = opdef;
    }
    @Override
    public void guardar() {
        System.out.println("usuario: " + nombre + " hora escojida " + opdef + ".");
    }
    @Override
    public String toString() {
        return "usuario :" + nombre + super.toString() + ", hora: " + opdef;
    }
}
