/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;
/**
 *
 * @author Usuario
 */
import java.io.*;
import java.util.ArrayList;

public class Admin implements Serializable {
    private static final String CONTRA = "55p54t";
    private static final String GAMES_FILE = "games.dat";
    private static final String USERS_FILE = "users.dat";
    
    private ArrayList<Game> invent;
    private ArrayList<Username> usuarios;
    
    public Admin() {
        this.invent = new ArrayList<>();
        this.usuarios = new ArrayList<>();
    }
    
    public void saveData() {
        savegame();
        saveUser();
    }
    
    private void savegame() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(GAMES_FILE))) {
            oos.writeObject(invent);
            System.out.println("Los datos se han guardados correctamente.");
        } catch (IOException e) {
            System.err.println("Error al guardar los datos  " + e.getMessage());
        }
    }
    
    private void saveUser() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILE))) {
            oos.writeObject(usuarios);
            System.out.println("Los Datos se han correctamente.");
        } catch (IOException e) {
            System.err.println("Error al guardar  los datos " + e.getMessage());
        }
    }
    
    public void loadData() {
        loadGame();
        loadUser();
    }
    
    private void loadGame() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(GAMES_FILE))) {
            invent = (ArrayList<Game>) ois.readObject();
            System.out.println("Datos cargados: " + invent.size() + " elementos.");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado. Se creará uno nuevo al guardar.");
            invent = new ArrayList<>();
        } catch (IOException e) {
            System.err.println("Error al leer el archivo :" + e.getMessage());
            invent = new ArrayList<>();
        } catch (ClassNotFoundException e) {
            System.err.println("Clase Game no encontrada: " + e.getMessage());
            invent = new ArrayList<>();
        }
    }
    
    private void loadUser() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USERS_FILE))) {
            usuarios = (ArrayList<Username>) ois.readObject();
            System.out.println("Datos cargados: " + usuarios.size() + " elementos.");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado. Se creará uno nuevo al guardar.");
            usuarios = new ArrayList<>();
        } catch (IOException e) {
            System.err.println("Error al leer el archivo : " + e.getMessage());
            usuarios = new ArrayList<>();
        } catch (ClassNotFoundException e) {
            System.err.println("Clase Username no encontrada: " + e.getMessage());
            usuarios = new ArrayList<>();
        }
    }
    
    public boolean check(String pass) {
        return CONTRA.equals(pass);
    }
    
    public boolean agregar(String room, String consola, double precio, String videog, boolean disponibilidad) {
        for (Game g : invent) {
            if (g.getroom().equals(room)) {
                return false;
            }
        }
        Game nwGame = new Game(room, consola, videog, precio, disponibilidad);
        invent.add(nwGame);
        savegame(); 
        return true;
    }
    
    public boolean editar(String room, String consola, double precio, String videog, boolean disponibilidad) {
        for (Game g : invent) {
            if (g.getroom().equals(room)) {
                g.setconsola(consola);
                g.setprecio(precio);
                g.setvideog(videog);
                g.setdisponibilidad(disponibilidad);
                savegame(); 
                return true;
            }
        }
        return false;
    }
    
    public boolean eliminar(String room) {
        for (int i = 0; i < invent.size(); i++) {
            if (invent.get(i).getroom().equals(room)) {
                invent.remove(i);
                savegame(); 
                return true;
            }
        }
        return false;
    }
    
    public void agregarUsuario(Username usuario) {
        usuarios.add(usuario);
        saveUser(); 
    }
    
    public void mostrar() {
        if (invent.isEmpty()) {
            System.out.println("No hay salas registradas.");
            return;
        }
        
        for (Game g : invent) {
            System.out.println(g);
        }
    }
    
    public void mostrarUsuarios() {
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }
        
        for (Username u : usuarios) {
            System.out.println(u);
        }
    }
    public ArrayList<Game> getinvent() {
        return new ArrayList<>(invent);
    }
    
    public ArrayList<Username> getUsuarios() {
        return new ArrayList<>(usuarios);
    }
}
