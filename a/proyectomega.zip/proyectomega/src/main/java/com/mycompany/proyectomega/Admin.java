/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;
/**
 *
 * @author Usuario
 */
import java.io.*;
import java.util.ArrayList;

public class Admin implements Serializable{
    private static final String Contra = "55p54t";
    private static final String Data = "inventario.dat";
    private ArrayList<Game> invent;
    public Admin (){
        this.invent = new java.util.ArrayList<>();
        Load();
    }
    public void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(Data))) {
            oos.writeObject(invent);
            System.out.println("Datos guardados correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }
    private void Load() {
        File archivo = new File(Data);
        if (!archivo.exists()) {
            System.out.println("los datos no se encuentra se toca implementar uno nuevo.");
            return;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Data))) {
            invent = (ArrayList<Game>) ois.readObject();
            System.out.println("Datos cargados. " + invent.size() + " elementos guardados.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public boolean check (String pass){
        return Contra.equals(pass);
    }
    public boolean agregar(String room, String consola, double precio, String videog, boolean disponibilidad) {
    for (Game g : invent) {
        if (g.getroom().equals(room)) {
            return false;
        }
    }
    Game nwGame = new Game(room, consola, videog, precio, disponibilidad);
    invent.add(nwGame);
    return true;
}
    public boolean editar (String room, String consola, double precio, String videog, boolean disponibilidad){
        for (Game g: invent){
            if(g.getroom().equals(room)){
                g.setconsola(consola);
                g.setprecio(precio);
                g.setvideog(videog);
                g.setdisponibilidad(disponibilidad);
                return true;
            }
        }
        return false;
    }
    public boolean eliminar(String room){
        for (int i = 0; i < invent.size(); i++){
            if (invent.get(i).getroom().equals(room)){
                invent.remove(i);
                return true;
            }
        }
        return false;
    }
    public void mostrar(){
        for(Game g: invent){
            System.out.print(g);
        }
    }
    public java.util.ArrayList<Game> getinvent(){
        return new java.util.ArrayList<>(invent);
    }
}