/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;

/**
 *
 * @author Usuario
 */
public class menu2 {
    static void meme2(Usuario user, java.util.Scanner scanner) {
        boolean b = false;
        while (!b) {
            System.out.println("digite una opcion:");
            System.out.println("1. buscar sala disponible:");
            System.out.println("2. mostrar salas");
            System.out.println("3.rentar sala");
            System.out.println("4.salir");
            int opcion3 = scanner.nextInt();
            scanner.nextLine();
            switch (opcion3){
                case 1->{
                    System.out.println("digite el codigo de la sala a buscar :");
                    String salabuscar = scanner.nextLine();
                    Game busc = user.Buscar(salabuscar);
                    if (busc != null){
                        System.out.println("sala encontrada :");
                        System.out.println(busc);
                    }else{
                        System.out.println("no se ha encontrado nada");
                    }
                    break;
                }
                case 2->{
                    user.mostrar();
                }
                case 3->{
                    System.out.println("digite el codigo de la sala a rentar :");
                    String rombusc = scanner.nextLine();
                    Game rent = user.Buscar(rombusc);
                    if (rent !=null){
                        if (rent.getdisponibilidad()){
                            System.out.println(rent);
                            
                            System.out.println("nombre:");
                            String mame = scanner.nextLine();
                            
                            System.out.println(" horas disponibles :");
                            System.out.println("1. " + rent.getopc1());
                            System.out.println("2. " + rent.getopc2());
                            System.out.println("3. " + rent.getopc3());
                            System.out.println("4. " + rent.getopc4());
                            System.out.println("5. " + rent.getopc5());
                            System.out.println("6. " + rent.getopc6());
                            System.out.println("7. " + rent.getopc7());
                            System.out.println("8. " + rent.getopc8());
                            System.out.println(" escoje :");
                            int opcion4 = scanner.nextInt();
                            String hora = "";
                            switch (opcion4){
                                case 1 ->{
                                    hora = rent.getopc1();
                                }
                                case 2 ->{
                                    hora = rent.getopc2();
                                }
                                case 3 ->{
                                    hora = rent.getopc3();
                                }
                                case 4 ->{
                                    hora = rent.getopc4();
                                }
                                case 5 ->{
                                    hora = rent.getopc5();
                                }
                                case 6 ->{
                                    hora = rent.getopc6();
                                }
                                case 7 ->{
                                    hora = rent.getopc7();
                                }
                                case 8 ->{
                                    hora = rent.getopc8();
                                }
                                default ->{
                                    System.out.println("error");
                                }
                            }
                            if (!hora.isEmpty()){
                                Username usuarionew = new Username (rent.getroom(), rent.getconsola(), rent.getvideog(), rent.getprecio(), rent.getdisponibilidad());
                                
                                usuarionew.setNombre(mame);
                                usuarionew.setOpdef(hora);
                                
                                usuarionew.guardar();
                                
                                if (user.pedir(rent.getroom())){
                                    System.out.println("se ha reaizado la reserva");
                                    System.out.println(usuarionew);
                                }else{
                                    System.out.println("error");
                                }
                            }
                        }else{
                            System.out.println("sala no disponible");
                        }
                    }else{
                        System.out.println("error");
                    }
                }
                case 4->{
                    b=true;
                }
                default ->{
                    System.out.println("error");
                    break;
                    
                }
            }
        }
    }
}
