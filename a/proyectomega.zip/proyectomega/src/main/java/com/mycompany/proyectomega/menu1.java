/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectomega;

/**
 *
 * @author Usuario
 */
public class menu1 {
    static void meme1(Admin admd, java.util.Scanner scanner) {
        boolean b = false;
        while (!b) {
            System.out.println("digite una opcion");
            System.out.println("1.Agregar ");
            System.out.println("2.Editar ");
            System.out.println("3.Eliminar ");
            System.out.println("4.Ver inventario");
            System.out.println("5.Volver al menú principal");
            int opcion2 = scanner.nextInt();
            scanner.nextLine();
            switch (opcion2){
                case 1->{
                    System.out.println("Digite el número de la sala:");
                    String room = scanner.nextLine();
                    System.out.println("Digite el nombre de la consola:");
                    String consola = scanner.nextLine();
                    System.out.println("Digite el precio por hora:");
                    double precio = scanner.nextDouble();
                    System.out.println("Digite el nombre de los  juegos disponible:");
                    String videogu = scanner.nextLine();
                    System.out.println("Digite si la consola está disponible (true/false):");
                    boolean disponibilidad = scanner.nextBoolean();
                    if(admd.agregar(room, consola, precio, videogu, disponibilidad)){
                        System.out.println("se ha agregado corectamente");
                    }else{
                        System.out.println("error");
                    }
                }
                case 2 ->{
                    System.out.print("numero de serie a editar: ");
                    String roomedit = scanner.nextLine();
                    System.out.print("nombre de consola: ");
                    String consolanew = scanner.nextLine();
                    System.out.print("Nuevo valor por hora: ");
                    double precionew = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.println("Digite los nuevos juegos disponibles:");
                    String videognew = scanner.nextLine();
                    System.out.println("Digite si la consola está disponible (true/false) otra vez:");
                    boolean disponibilidadnew = scanner.nextBoolean();
                    
                    if (admd.editar(roomedit, consolanew, precionew, videognew, disponibilidadnew)) {
                        System.out.println("se ha editado correctamente.");
                    } else {
                        System.out.println("Error.");
                    }
                }
                case 3 ->{
                    System.out.print("digite el codigo de sala a eliminar ");
                    String roomelim = scanner.nextLine();
                    
                    if (admd.eliminar(roomelim)) {
                        System.out.println("Producto eliminado correctamente.");
                    } else {
                        System.out.println("Error: No se encontró el producto.");
                    }
                    break;
                }
                case 4 -> admd.mostrar();
                case 5 -> {
                    b=true;
                }
                default ->{
                    System.out.println("error");
                    break;
                }
            }
        }
    }
}